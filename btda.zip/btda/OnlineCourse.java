package btda;

public class OnlineCourse {
    String tenkhoahoc;
    String giangvien;
    double gia;

    public OnlineCourse(String _tenkhoahoc, String _giangvien, double _gia) {
        this.tenkhoahoc = _tenkhoahoc;
        this.giangvien = _giangvien;
        this.gia = _gia;
    }

    public double getGia() {
        return gia;
    }

    public String getTenkhoahoc() {
        return tenkhoahoc;
    }

    public String toString() {
        return "Khóa học: " + this.tenkhoahoc +
               ", Giảng viên: " + this.giangvien +
               ", Giá: " + this.gia;
    }
}

