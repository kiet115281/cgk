package btda;

import java.util.ArrayList;

public class CourseOrder {
    Learner hocvien;
    ArrayList<OnlineCourse> danhsachkhoahoc;

    public CourseOrder(Learner _hocvien) {
        hocvien = _hocvien;
        danhsachkhoahoc = new ArrayList<>();
    }

    public void themKhoaHoc(OnlineCourse kh) {
        danhsachkhoahoc.add(kh);
    }

    public double tinhTongTien() {
        double tong = 0;

        for (OnlineCourse kh : danhsachkhoahoc) {
            tong += kh.gia; 
        }

        if (danhsachkhoahoc.size() >= 3) {
            tong = tong * 0.8;
        }

        return tong;
    }

    public void inThongTin() {
        System.out.println(hocvien);
        System.out.println("Danh sách khóa học đã đăng ký:");
        for (OnlineCourse kh : danhsachkhoahoc) {
            System.out.println("- " + kh);
        }
        System.out.println("Tổng tiền phải trả: " + tinhTongTien());
    }
}
