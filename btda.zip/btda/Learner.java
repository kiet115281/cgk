package btda;

public class Learner {
    String name;
    String email;

    public Learner(String _name, String _email) {
        this.name = _name;
        this.email = _email;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return "Học viên: " + this.name + ", Email: " + this.email;
    }
}

