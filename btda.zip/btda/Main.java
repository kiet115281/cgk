package btda;

public class Main {
    public static void main(String[] args) {

        Learner hv = new Learner("Cao Gia Kiệt", "caogiakiet51@gmail.com");

        OnlineCourse k1 = new OnlineCourse("Java ", "Thầy Hiệu", 100);
        OnlineCourse k2 = new OnlineCourse("Python", "Thầy Thà ", 120);
        OnlineCourse k3 = new OnlineCourse("SQL", "Thầy Vương", 80);

        CourseOrder order = new CourseOrder(hv);

        order.themKhoaHoc(k1);
        order.themKhoaHoc(k2);
        order.themKhoaHoc(k3);

        order.inThongTin();
    }
}
